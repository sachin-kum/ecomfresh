const express = require("express");
const errorMiddleware = require("./middleware/error");
const cookieParaser = require("cookie-parser");
const app = express();
const cors = require("cors");
const multer = require("module");
app.use(express.json());

const products = require("./routes/productRoute");
const user = require("./routes/userRoute");
const order = require("./routes/orderRoute");
const upload = require("./middleware/fileupload");
const cart = require("./routes/cartRoutes");

app.use(
  cors({
    origin: "*",
  })
);

app.use("/", express.static(__dirname + "/upload"));
// app.use(upload.any());
app.use(cookieParaser());

app.use("/api/v1", cart);
app.use("/api/v1", products);
app.use("/api/v1", user);
app.use("/api/v1", order);
//cookei handle

// error hanndle for
app.use(errorMiddleware);
module.exports = app;
